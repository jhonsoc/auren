/* eslint-disable prettier/prettier */
// src/common/enums/role.enum.ts
export enum RolUsuario {
  SUPERADMIN = 'superadmin',
  ADMIN_EMPRESA = 'admin_empresa',
  COLABORADOR = 'colaborador',
}
