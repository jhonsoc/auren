/* eslint-disable prettier/prettier */
export class CreateEmpresaDto {
  nit: string;
  razonSocial: string;
  direccion: string;
  telefono: string;
}