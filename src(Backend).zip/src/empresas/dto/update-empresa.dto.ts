/* eslint-disable prettier/prettier */
export class UpdateEmpresaDto {
  nit?: string;
  razonSocial?: string;
  direccion?: string;
  telefono?: string;
}